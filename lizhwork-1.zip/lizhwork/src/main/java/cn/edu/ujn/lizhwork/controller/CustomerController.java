package cn.edu.ujn.lizhwork.controller;

import cn.edu.ujn.lizhwork.dao.Customer;
import cn.edu.ujn.lizhwork.service.ICustomerService;
import cn.edu.ujn.util.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/customer")
public class CustomerController {

    @Autowired
    private ICustomerService customerService;

    // 列表显示所有内容
    @GetMapping
    public String list(@RequestParam(value = "page", defaultValue = "1") Integer page,
                       @RequestParam(value = "rows", defaultValue = "10") Integer rows,
                       @ModelAttribute Customer customer, Model model) {
        // 设置分页参数
        customer.setStart((page - 1) * rows);
        customer.setRows(rows);

        Page<Customer> pageResult = customerService.selectAll(customer);
        pageResult.setPage(page);
        model.addAttribute("page", pageResult);

        // 将查询条件回显到页面
        model.addAttribute("custName", customer.getCustName());
        model.addAttribute("custPhone", customer.getCustPhone());
        model.addAttribute("custPid", customer.getCustPid());
        model.addAttribute("custRemark", customer.getCustRemark());
        model.addAttribute("custRegi", customer.getCustRegi());
        model.addAttribute("custGender", customer.getCustGender());
        System.out.println("查询结果数量: " + pageResult.getRows().size());
        return "customer";
    }

    @GetMapping("/search")
    @ResponseBody
    public List<Customer> searchCustomers(@RequestParam String keyword) {
        return customerService.searchCustomerByName(keyword);
    }


    // 新建教职工信息
    @PostMapping
    @ResponseBody
    public String create(@RequestBody Customer customer) {
        try {
            // 验证必要字段
            if (customer.getCustName() == null || customer.getCustName().isEmpty() ||
                    customer.getCustPhone() == null ||
                    customer.getCustPid() == null || customer.getCustPid().isEmpty()) {
                return "FAIL: Missing required fields";
            }

            int result = customerService.insert(customer);
            return result > 0 ? "OK" : "FAIL";
        } catch (Exception e) {
            e.printStackTrace();
            return "FAIL: " + e.getMessage();
        }
    }

    // 根据ID查询教职工信息（用于修改前的数据回显）
    @GetMapping("/{id}")
    @ResponseBody
    public Customer getById(@PathVariable("id") Integer id) {
        return customerService.selectByPrimaryKey(id);

    }

    // 修改教职工信息
    @PutMapping
    @ResponseBody
    public String update(@RequestBody Customer customer) {
        try {

            int result = customerService.updateByPrimaryKeySelective(customer);
            return result > 0 ? "OK" : "FAIL";
        } catch (Exception e) {
            e.printStackTrace();
            return "FAIL";
        }
    }

    // 删除教职工信息
    @DeleteMapping("/{id}")
    @ResponseBody
    public String delete(@PathVariable("id") Integer id) {
        try {

            int result = customerService.deleteByPrimaryKey(id);
            return result > 0 ? "OK" : "FAIL";
        } catch (Exception e) {
            e.printStackTrace();
            return "FAIL";
        }
    }

}
