package cn.edu.ujn.lizhwork.dao;

public class Staff {
    private Integer staffId;

    private String staffName;

    private String staffDepartment;

    private String staffWorkplace;

    private Integer staffSalary;

    private String staffStatus;

    private Long staffPhone;

    private String staffGender;

    public Integer getStaffId() {
        return staffId;
    }

    public void setStaffId(Integer staffId) {
        this.staffId = staffId;
    }

    public String getStaffName() {
        return staffName;
    }

    public void setStaffName(String staffName) {
        this.staffName = staffName == null ? null : staffName.trim();
    }

    public String getStaffDepartment() {
        return staffDepartment;
    }

    public void setStaffDepartment(String staffDepartment) {
        this.staffDepartment = staffDepartment == null ? null : staffDepartment.trim();
    }

    public String getStaffWorkplace() {
        return staffWorkplace;
    }

    public void setStaffWorkplace(String staffWorkplace) {
        this.staffWorkplace = staffWorkplace == null ? null : staffWorkplace.trim();
    }

    public Integer getStaffSalary() {
        return staffSalary;
    }

    public void setStaffSalary(Integer staffSalary) {
        this.staffSalary = staffSalary;
    }

    public String getStaffStatus() {
        return staffStatus;
    }

    public void setStaffStatus(String staffStatus) {
        this.staffStatus = staffStatus == null ? null : staffStatus.trim();
    }

    public Long getStaffPhone() {
        return staffPhone;
    }

    public void setStaffPhone(Long staffPhone) {
        this.staffPhone = staffPhone;
    }

    public String getStaffGender() {
        return staffGender;
    }

    public void setStaffGender(String staffGender) {
        this.staffGender = staffGender == null ? null : staffGender.trim();
    }
}