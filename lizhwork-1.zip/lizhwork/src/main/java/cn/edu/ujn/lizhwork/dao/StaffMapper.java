package cn.edu.ujn.lizhwork.dao;

import cn.edu.ujn.lizhwork.dao.Staff;

public interface StaffMapper {
    int deleteByPrimaryKey(Integer staffId);

    int insert(Staff row);

    int insertSelective(Staff row);

    Staff selectByPrimaryKey(Integer staffId);

    int updateByPrimaryKeySelective(Staff row);

    int updateByPrimaryKey(Staff row);
}