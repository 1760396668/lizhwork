package cn.edu.ujn.lizhwork.dao;

import cn.edu.ujn.lizhwork.dao.Reservation;

public interface ReservationMapper {
    int deleteByPrimaryKey(Integer reservationId);

    int insert(Reservation row);

    int insertSelective(Reservation row);

    Reservation selectByPrimaryKey(Integer reservationId);

    int updateByPrimaryKeySelective(Reservation row);

    int updateByPrimaryKey(Reservation row);
}