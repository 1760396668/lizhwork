package cn.edu.ujn.lizhwork.dao;

import java.util.Date;

public class Customer {
    private Integer custId;

    private String custName;

    private Long custPhone;

    private String custPid;

    private String custRemark;

    private Date custRegi;

    private String custGender;

    private Integer start;

    private Integer rows;

    public Integer getStart() {
        return start;
    }

    public void setStart(Integer start) {
        this.start = start;
    }

    public Integer getRows() {
        return rows;
    }

    public void setRows(Integer rows) {
        this.rows = rows;
    }

    @Override
    public String toString() {
        return "Customer{" +
                "custId=" + custId +
                ", custName='" + custName + '\'' +
                ", custPhone=" + custPhone +
                ", custPid='" + custPid + '\'' +
                ", custRemark='" + custRemark + '\'' +
                ", custRegi=" + custRegi +
                ", custGender='" + custGender + '\'' +
                ", start=" + start +
                ", rows=" + rows +
                '}';
    }

    public Integer getCustId() {
        return custId;
    }

    public void setCustId(Integer custId) {
        this.custId = custId;
    }

    public String getCustName() {
        return custName;
    }

    public void setCustName(String custName) {
        this.custName = custName == null ? null : custName.trim();
    }

    public Long getCustPhone() {
        return custPhone;
    }

    public void setCustPhone(Long custPhone) {
        this.custPhone = custPhone;
    }

    public String getCustPid() {
        return custPid;
    }

    public void setCustPid(String custPid) {
        this.custPid = custPid == null ? null : custPid.trim();
    }

    public String getCustRemark() {
        return custRemark;
    }

    public void setCustRemark(String custRemark) {
        this.custRemark = custRemark == null ? null : custRemark.trim();
    }

    public Date getCustRegi() {
        return custRegi;
    }

    public void setCustRegi(Date custRegi) {
        this.custRegi = custRegi;
    }

    public String getCustGender() {
        return custGender;
    }

    public void setCustGender(String custGender) {
        this.custGender = custGender == null ? null : custGender.trim();
    }
}