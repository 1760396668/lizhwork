package cn.edu.ujn.lizhwork.service;

import cn.edu.ujn.lizhwork.dao.Customer;
import cn.edu.ujn.util.Page;

import java.util.List;

public interface ICustomerService {
    int deleteByPrimaryKey(Integer custId);
    int insert(Customer customer);
    Customer selectByPrimaryKey(Integer custId);
    int updateByPrimaryKey(Customer customer);
    Page<Customer> selectAll(Customer customer);
    List<Customer> searchCustomerByName(String custName);

    int updateByPrimaryKeySelective(Customer customer);
}
