package cn.edu.ujn.lizhwork.dao;

import cn.edu.ujn.lizhwork.dao.Room;

public interface RoomMapper {
    int deleteByPrimaryKey(Integer roomId);

    int insert(Room row);

    int insertSelective(Room row);

    Room selectByPrimaryKey(Integer roomId);

    int updateByPrimaryKeySelective(Room row);

    int updateByPrimaryKey(Room row);
}