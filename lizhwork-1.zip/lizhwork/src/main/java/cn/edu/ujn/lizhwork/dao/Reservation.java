package cn.edu.ujn.lizhwork.dao;

import java.util.Date;

public class Reservation {
    private Integer reservationId;

    private Integer customerId;

    private Integer roomId;

    private Date checkInDate;

    private Date checkOurDate;

    private Date reservationDate;

    private String reservationStatus;

    public Integer getReservationId() {
        return reservationId;
    }

    public void setReservationId(Integer reservationId) {
        this.reservationId = reservationId;
    }

    public Integer getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Integer customerId) {
        this.customerId = customerId;
    }

    public Integer getRoomId() {
        return roomId;
    }

    public void setRoomId(Integer roomId) {
        this.roomId = roomId;
    }

    public Date getCheckInDate() {
        return checkInDate;
    }

    public void setCheckInDate(Date checkInDate) {
        this.checkInDate = checkInDate;
    }

    public Date getCheckOurDate() {
        return checkOurDate;
    }

    public void setCheckOurDate(Date checkOurDate) {
        this.checkOurDate = checkOurDate;
    }

    public Date getReservationDate() {
        return reservationDate;
    }

    public void setReservationDate(Date reservationDate) {
        this.reservationDate = reservationDate;
    }

    public String getReservationStatus() {
        return reservationStatus;
    }

    public void setReservationStatus(String reservationStatus) {
        this.reservationStatus = reservationStatus == null ? null : reservationStatus.trim();
    }
}