package cn.edu.ujn.lizhwork.service;

import cn.edu.ujn.lizhwork.dao.Customer;
import cn.edu.ujn.lizhwork.dao.CustomerMapper;
import cn.edu.ujn.util.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.awt.*;
import java.util.List;

@Service
public class CustomerServiceImpl implements ICustomerService{

    @Autowired
    private CustomerMapper customerMapper;

    @Override
    public int deleteByPrimaryKey(Integer custId) {
        return customerMapper.deleteByPrimaryKey(custId);
    }

    @Override
    public int insert(Customer customer) {
        return customerMapper.insert(customer);
    }

    @Override
    public Customer selectByPrimaryKey(Integer custId) {
        return customerMapper.selectByPrimaryKey(custId);
    }

    @Override
    public int updateByPrimaryKey(Customer customer) {
        return customerMapper.updateByPrimaryKey(customer);
    }

    @Override
    public Page<Customer> selectAll(Customer customer) {
        Page<Customer> page = new Page<>();
        page.setPage(customer.getStart());
        page.setSize(customer.getRows());
        page.setTotal(customerMapper.selectCount());
        page.setRows(customerMapper.selectAll(customer));
        return page;
    }

    @Override
    public List<Customer> searchCustomerByName(String custName) {
        return customerMapper.selectByName(custName);
    }

    @Override
    public int updateByPrimaryKeySelective(Customer customer) {
        return customerMapper.updateByPrimaryKeySelective(customer);
    }
}
