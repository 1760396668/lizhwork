package cn.edu.ujn.lizhwork.dao;

import cn.edu.ujn.lizhwork.dao.Customer;
import org.apache.ibatis.annotations.Select;

import java.util.List;

public interface CustomerMapper {
    int deleteByPrimaryKey(Integer custId);

    int insert(Customer row);

    int insertSelective(Customer row);

    Customer selectByPrimaryKey(Integer custId);

    int updateByPrimaryKeySelective(Customer row);

    int updateByPrimaryKey(Customer row);

    List<Customer> selectAll(Customer row);

    Integer selectCount();

    List<Customer> selectByName(String custName);

}