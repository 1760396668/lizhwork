/*
SQLyog Ultimate v12.08 (64 bit)
MySQL - 8.0.39 : Database - final
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`final` /*!40100 DEFAULT CHARACTER SET utf8mb3 */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `final`;

/*Table structure for table `customer` */

DROP TABLE IF EXISTS `customer`;

CREATE TABLE `customer` (
  `cust_id` int NOT NULL AUTO_INCREMENT,
  `cust_name` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `cust_phone` bigint NOT NULL,
  `cust_pid` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `cust_remark` varchar(50) DEFAULT NULL,
  `cust_regi` date DEFAULT NULL,
  `cust_gender` varchar(2) DEFAULT NULL,
  PRIMARY KEY (`cust_id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `customer` */

insert  into `customer`(`cust_id`,`cust_name`,`cust_phone`,`cust_pid`,`cust_remark`,`cust_regi`,`cust_gender`) values (1,'张伟',111111111111,'1101011990010169','常客，需要叫醒服务','2025-05-31','男'),(2,'李娜',13900139444,'110101199102022345','VIP客户，偏好高层','2025-06-08','女'),(3,'王芳',13700137003,'110101198503033456','商务客户，需要发票','2021-03-10','女'),(4,'赵明',13600136004,'110101197704044567','带儿童，需要婴儿床','2022-06-18','男'),(5,'刘强',1355555555,'110101198905055678','家庭套房常客','2022-01-05','男'),(6,'Robert Smith',8613800138006,'PASSPORT12345678','外国游客，需要英文服务','2023-02-14','男'),(7,'Emma Johnson',8613900139007,'PASSPORT87654321','长租客户','2023-01-20','女'),(15,'陈晨',13400134008,'320102199203034321','商务出差，需要早叫服务','2023-04-12','男'),(16,'林小美',15900159009,'440304199508087654','旅游客户，喜欢景点推荐','2023-05-20','女'),(17,'黄建国',18600186010,'110108197812120987','退休教师，偏好安静房间','2023-03-15','男'),(18,'周敏',13100131011,'310105198611112345','会议客户，需要会议室','2023-06-08','女'),(20,'李',47985968230,'58972679523','你好',NULL,'男');

/*Table structure for table `reservation` */

DROP TABLE IF EXISTS `reservation`;

CREATE TABLE `reservation` (
  `reservation_id` int NOT NULL AUTO_INCREMENT,
  `customer_id` int NOT NULL,
  `room_id` int NOT NULL,
  `check_in_date` date NOT NULL,
  `check_our_date` date NOT NULL,
  `reservation_date` datetime DEFAULT NULL,
  `reservation_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'confirmed',
  PRIMARY KEY (`reservation_id`),
  KEY `customer_id` (`customer_id`),
  KEY `room_id` (`room_id`),
  CONSTRAINT `reservation_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`cust_id`),
  CONSTRAINT `reservation_ibfk_2` FOREIGN KEY (`room_id`) REFERENCES `room` (`room_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `reservation` */

insert  into `reservation`(`reservation_id`,`customer_id`,`room_id`,`check_in_date`,`check_our_date`,`reservation_date`,`reservation_status`) values (1,1,3,'2025-06-15','2025-06-17','2025-06-15 10:05:53','confirmed'),(2,2,5,'2025-06-18','2025-06-19','2025-06-16 10:07:20','check_in'),(3,3,7,'2025-06-16','2025-06-27','2025-06-15 10:08:15','confirmed'),(4,4,10,'2025-06-16','2025-06-17','2025-06-14 10:09:08','confirmed'),(5,5,12,'2025-06-18','2025-06-20','2025-06-12 10:09:49','check_in'),(6,6,16,'2025-06-16','2025-06-19','2025-06-15 10:11:11','confirmed');

/*Table structure for table `room` */

DROP TABLE IF EXISTS `room`;

CREATE TABLE `room` (
  `room_id` int NOT NULL AUTO_INCREMENT,
  `room_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `room_number` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `room_state` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'available',
  `room_price` int NOT NULL,
  `room_remark` tinytext,
  PRIMARY KEY (`room_id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `room` */

insert  into `room`(`room_id`,`room_type`,`room_number`,`room_state`,`room_price`,`room_remark`) values (1,'标准间','101','available',300,'安静靠南，配备2张1.2米床'),(2,'标准间','102','available',300,'靠近电梯，配备2张1.8米大床'),(3,'标准间','103','occupied',300,'临街房间，配备2张1.2米床'),(4,'标准间','104','maintenance',300,'空调维修中，暂停使用'),(5,'豪华间','201','reserve',500,'海景房，带阳台，配备1张2米大床'),(6,'豪华间','202','available',500,'配备浴缸和智能马桶'),(7,'豪华间','203','occupied',500,'蜜月布置，配备圆形水床'),(8,'豪华间','204','available',500,'连通房，可与其他房间组合'),(9,'商务套房','301','available',800,'带小型会议室和办公区'),(10,'商务套房','302','occupied',800,'配备胶囊咖啡机和迷你吧'),(11,'商务套房','303','available',800,'转角套房，视野开阔'),(12,'总统套房','401','reserve',1500,'240平米，含客厅、餐厅和书房'),(13,'总统套房','402','available',1800,'300平米，带私人泳池和SPA区'),(14,'家庭房','501','available',600,'1张双人床+2张单人床，带儿童游乐区'),(15,'家庭房','502','available',650,'2张双人床，配备婴儿床和儿童用品'),(16,'家庭房','503','occupied',600,'亲子主题房，带玩具和绘本'),(17,'家庭房','504','available',700,'套房式家庭房，带厨房和客厅'),(18,'大床房','601','available',400,'1.8米舒适大床，安静角落房'),(19,'大床房','602','available',450,'2米豪华大床，配备按摩枕'),(20,'大床房','603','occupied',400,'蜜月布置，赠送红酒和水果'),(21,'大床房','604','available',420,'商务大床房，带办公桌和高速网络'),(22,'大床房','605','maintenance',400,'浴室升级改造中，预计下周开放');

/*Table structure for table `staff` */

DROP TABLE IF EXISTS `staff`;

CREATE TABLE `staff` (
  `staff_id` int NOT NULL AUTO_INCREMENT,
  `staff_name` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `staff_department` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `staff_workplace` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `staff_salary` int NOT NULL,
  `staff_status` varchar(20) DEFAULT NULL,
  `staff_phone` bigint NOT NULL,
  `staff_gender` varchar(2) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`staff_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `staff` */

insert  into `staff`(`staff_id`,`staff_name`,`staff_department`,`staff_workplace`,`staff_salary`,`staff_status`,`staff_phone`,`staff_gender`) values (1,'张丽','前台','大堂前台',4500,'在职',13800138001,'女'),(2,'王强','前台','礼宾部',4000,'在职',13900139002,'男'),(3,'李娜','前台','预订部',4800,'休假',13700137003,'女'),(4,'张阿姨','客房服务','1-2楼清洁',3800,'在职',13600136004,'女'),(5,'王阿姨','客房服务','3-4楼清洁',3800,'在职',13600136004,'女'),(6,'陈阿姨','客房服务','5-6楼清洁',3800,'在职',13600136004,'女'),(7,'吴师傅','客房服务','布草间',4200,'在职',13500135005,'男'),(8,'赵姐','客房服务','楼层主管',5000,'在职',13400134006,'女'),(9,'周明','餐饮','中餐厅',4000,'在职',13300133007,'男'),(10,'钱芳','餐饮','西餐厅',4200,'在职',13200132008,'女'),(11,'孙大厨','餐饮','厨房',6000,'在职',13100131009,'男'),(12,'杨经理','管理','总经理办公室',8000,'在职',13000130010,'男'),(13,'刘总监','管理','人力资源部',7500,'在职',15900159011,'女'),(14,'黄会计','管理','财务部',6500,'在职',15800158012,'女');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
